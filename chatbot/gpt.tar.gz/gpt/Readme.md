open the fiel .env 
this file is hiden chang eteh beare token to your own chatgpt beare token 
from there test the bot out