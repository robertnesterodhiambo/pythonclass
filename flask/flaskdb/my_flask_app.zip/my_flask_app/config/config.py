# config/config.py

DATABASE = 'your_database_name.db'
