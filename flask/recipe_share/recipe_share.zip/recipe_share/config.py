class Config:
    SECRET_KEY = 'Saksoki'  
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = '1234'
    MYSQL_DB = 'recipe_share'
